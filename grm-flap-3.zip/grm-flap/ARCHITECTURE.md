# GRM FLAP — ընդհանուր ճարտարապետություն

```
┌──────────────┐     ┌───────────────┐     ┌──────────────────────────────┐
│ Telegram Bot │ --> │   Mini App    │ --> │           GAME                │
│   (bot.js)   │     │ (index.html)  │     │  physics.js (client-side run) │
└──────────────┘     └───────────────┘     └──────────────┬────────────────┘
                                                            │ flapLog (ե՞րբ ես flap-ել)
                                                            ▼
┌──────────────┐     ┌───────────────┐     ┌──────────────────────────────┐
│   Weekly     │ <-- │  Leaderboard  │ <-- │   Server (server.js)          │
│  GRM Rewards │     │ (store.js)    │     │  վերարտադրում է խաղը seed-ով  │
│ (rewards.js) │     │               │     │  physics.js-ով → score        │
└──────────────┘     └───────────────┘     └──────────────┬────────────────┘
                                                            │
                                                   telegramAuth.js
                                                (ստուգում է, որ իրական
                                                 Telegram user-ից է)
```

## Ֆայլերի քարտեզ (ինչ ինչի հետ է կապված)

| Ֆայլ | Աշխատում է | Ինչ է անում | Կապված է |
|---|---|---|---|
| `bot.js` | Node.js (bot process) | Ուղարկում է "▶ Play" կոճակ, որը բացում է Mini App-ը | → `index.html` (URL-ով) |
| `index.html` | Browser (Telegram-ի ներսում) | Խաղը, Telegram WebApp SDK, ուղարկում է flapLog սերվեր | → `physics.js`, → `server.js` (API-ով) |
| `physics.js` | **Երկուսում էլ**՝ browser + Node | Deterministic simulation (fizika-ն նույնն է երկու կողմում) | Օգտագործվում է `index.html`-ի և `server.js`-ի կողմից |
| `server.js` | Node.js (backend) | Session տալիս, score-ը վերահաշվարկում, leaderboard API | → `physics.js`, `telegramAuth.js`, `store.js`, `rewards.js` |
| `telegramAuth.js` | Node.js | Ստուգում է initData-ի ստորագրությունը | Օգտագործվում է `server.js`-ից |
| `store.js` | Node.js | Session-ներ, weekly leaderboard (in-memory, փոխարինելի Redis/DB-ով) | Օգտագործվում է `server.js`, `rewards.js`-ից |
| `rewards.js` | Node.js | Շաբաթական GRM tier-երը և payout stub-ը | Օգտագործվում է `server.js`-ից (`/internal/run-weekly-rewards`) |

## Ամբողջական flow-ը՝ քայլ առ քայլ

1. **Bot** → user-ը սեղմում է "Play" → բացվում է **Mini App** (`index.html`)
2. Mini App-ը `tg.ready()` / `tg.expand()` → ստանում է Telegram-ից `initData`
3. Player-ը սեղմում է **START** → client-ը կանչում է `POST /api/start-session`
4. **Server**-ը ստուգում է `initData`-ն (`telegramAuth.js`), տալիս random `seed` + `sessionId`
5. **Rewarded ad** (ըստ ցանկության) → bonus-ը հաստատվում է ad ցանցի կողմից, ոչ թե client-ի
6. Player-ը խաղում է. `physics.js`-ը (browser-ում) վազում է `seed`-ով, client-ը գրանցում է **միայն flap-երի ժամանակները**, ոչ թե score-ը
7. Game over → `POST /api/submit-score` `{sessionId, flapLog}`
8. **Server**-ը `physics.js`-ով (Node-ում) վերարտադրում է **ճիշտ նույն խաղը** → հաշվում է իրական score-ը
9. Score-ը գրվում է **weekly leaderboard**-ում (`store.js`), session-ը փակվում է (single-use)
10. `GET /api/leaderboard` → Mini App-ը ցույց է տալիս top-ը + player-ի rank-ը
11. Շաբաթը ավարտվելուն պես՝ **cron** (կամ admin endpoint) կանչում է `runWeeklyRewardJob()` (`rewards.js`) → հաշվում GRM-ները ըստ rank-ի → `distributeGrmRewards()` (stub, պետք է միացնես իրական GRM transfer-ը)

## Ինչու չի կարելի խաբել

Client-ը երբեք չի ասում "իմ score-ը X է" — ասում է միայն "ես flap արեցի այս պահերին", և **սերվերն ինքն է հաշվում** score-ը՝ նույն `physics.js`-ով։ Ամբողջական մանրամասները՝ `README.md`-ում, բաժին **"Why the score can't be faked"**։

## Deploy hosting-ի հերթականությունը

1. Deploy **backend**-ը (`server.js` + մյուս `.js` ֆայլերը) HTTPS domain-ի վրա → ստացիր `https://api.yourdomain.com`
2. `index.html`-ում ավելացրու վերևում՝
   ```html
   <script>window.GRM_FLAP_API_BASE = "https://api.yourdomain.com";</script>
   ```
3. Deploy **`index.html` + `physics.js`**-ը static hosting-ի վրա (նույն կամ այլ HTTPS domain)
4. BotFather-ում կարգավորիր Mini App URL-ը դեպի այդ `index.html`-ը
5. Գործարկիր `bot.js`-ը (կամ քո bot-ի ինֆրաստրուկտուրայում ավելացրու "Play" կոճակը)
